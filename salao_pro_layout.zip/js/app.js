document.getElementById("formAgendamento").addEventListener("submit", function(e){
  e.preventDefault();
  const dados = {
    nome: nome.value,
    telefone: telefone.value,
    servico: servico.value,
    data: data.value
  };
  let lista = JSON.parse(localStorage.getItem("agendamentos") || "[]");
  lista.push(dados);
  localStorage.setItem("agendamentos", JSON.stringify(lista));
  alert("Agendado com sucesso!");
});
